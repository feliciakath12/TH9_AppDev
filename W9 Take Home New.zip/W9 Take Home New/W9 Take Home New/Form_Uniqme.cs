﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W9_Take_Home_New
{
    public partial class Form_UNIQME : Form
    {
        DataTable dtProduk;
        DataTable dtsimpanharga;

        string simpanrupiah;

        int countO = 0;
        int countA = 0;

        int Total = 0;

        long subtotal = 0;
        long simpanharga = 0;

        public Form_UNIQME()
        {
            InitializeComponent();
            dtProduk = new DataTable();
            dtProduk.Columns.Add("Item Name");
            dtProduk.Columns.Add("Quantity");
            dtProduk.Columns.Add("Price");
            dtProduk.Columns.Add("Total");
            dgv_Produk.DataSource = dtProduk;
            
            dtsimpanharga = new DataTable();
            dtsimpanharga.Columns.Add("HargaInt");
        }

        private void Form_UNIQME_Load(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Jewellery.Visible = false;
            pnl_Others.Visible = false;
        }

        private void totalharga()
        {
            if (dgv_Produk.Rows.Count > 0)
            {
                subtotal = 0;
                simpanharga = 0;
                for (int i = 0; i < dtsimpanharga.Rows.Count; i++)
                {
                    simpanharga = Int64.Parse(dtsimpanharga.Rows[i][0].ToString());
                    subtotal += simpanharga;
                }

                tb_SubTotal.Text = subtotal.ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                tb_Total.Text = (subtotal + (0.1 * subtotal)).ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
            }
        }

        private void format(int Total)
        {
            simpanrupiah = Total.ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Jewellery.Visible = false;
            pnl_Others.Visible = false;
            pnl_TShirt.Visible = true;
        }

        private void btn_AddCartTShirt1_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_TShirtKerahBulat.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 120000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_TShirtKerahBulat.Text, countA, lb_HargaTShirtKerahBulat.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 120000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCartTShirt2_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_TShirtAIRism.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 150000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_TShirtAIRism.Text, countA, lb_HargaTShirtAIRism.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 150000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCartTShirt3_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_TShirtVNeck.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 170000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_TShirtVNeck.Text, countA, lb_HargaTShirtVNeck.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 170000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Jewellery.Visible = false;
            pnl_Others.Visible = false;
            pnl_Shirt.Visible = true; ;
        }

        private void btn_AddCartShirt1_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_ShortSleeveShirt.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 200000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_ShortSleeveShirt.Text, countA, lb_HargaShortSleeveShirt.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 200000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCart2_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_ClassicWhiteShirt.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 190000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_ClassicWhiteShirt.Text, countA, lb_HargaClassicWhiteShirt.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 190000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCartShirt3_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_CottonShirt.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 220000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_CottonShirt.Text, countA, lb_HargaCottonShirt.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 220000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
            
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Jewellery.Visible = false;
            pnl_Others.Visible = false;
            pnl_Pants.Visible = true;
        }

        private void btn_AddCartPants1_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_LightPants.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 160000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_LightPants.Text, countA, lb_HargaLightPants.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 160000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCartPants2_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_BlackAnklePants.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 200000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_BlackAnklePants.Text, countA, lb_HargaBlackAnklePants.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 200000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCartPants3_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_WomenPants.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 250000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_WomenPants.Text, countA, lb_HargaWomenPants.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 250000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Jewellery.Visible = false;
            pnl_Others.Visible = false;
            pnl_LongPants.Visible = true;
        }

        private void btn_AddCartLongPants1_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_CargoLongPants.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 240000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_CargoLongPants.Text, countA, lb_HargaCargoLongPants.Text, simpanrupiah);

            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 240000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCartLongPants2_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_BlackLongPants.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 180000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_BlackLongPants.Text, countA, lb_HargaBlackLongPants.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 180000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCartLongPants3_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_CasualLongPants.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 230000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_CasualLongPants.Text, countA, lb_HargaCasualLongPants.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 230000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Jewellery.Visible = false;
            pnl_Others.Visible = false;
            pnl_Shoes.Visible = true;
        }

        private void btn_AddCartShoe1_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_RunningShoes.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 300000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_RunningShoes.Text, countA, lb_HargaRunningShoes.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 300000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCartShoe2_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_SneakersShoes.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 290000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_SneakersShoes.Text, countA, lb_HargaSneakersShoes.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 290000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCartShoe3_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_FlatShoes.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 320000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_FlatShoes.Text, countA, lb_HargaFlatShoes.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 320000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Others.Visible = false;
            pnl_Jewellery.Visible = true;
        }

        private void btn_AddCartJewellery1_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_RingJewellery.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 600000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_RingJewellery.Text, countA, lb_HargaRingJewellery.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 600000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCartJewellery2_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_NecklaceJewellery.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 650000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_NecklaceJewellery.Text, countA, lb_HargaNecklaceJewellery.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 650000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void btn_AddCartJewellery3_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (dtProduk.Rows[i][0].ToString() == lb_BraceletJewellery.Text)
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if (sama == false)
            {
                countA = 1;
                Total = countA * 500000;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(lb_BraceletJewellery.Text, countA, lb_HargaBraceletJewellery.Text, simpanrupiah);
            }
            else if (sama == true)
            {
                countA = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countA++;
                Total = countA * 500000;

                format(Total);

                dtProduk.Rows[simpan][1] = countA;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_TShirt.Visible = false;
            pnl_Shirt.Visible = false;
            pnl_Pants.Visible = false;
            pnl_LongPants.Visible = false;
            pnl_Shoes.Visible = false;
            pnl_Jewellery.Visible = false;
            pnl_Others.Visible = true;
        }

        private void btn_Upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfile = new OpenFileDialog();
            openfile.Filter = "Image Files (*.jpg;*.jpeg;*.PNG;*.All files;)|*.jpg;*.jpeg;*.PNG;*.All files";
            if(openfile.ShowDialog() == DialogResult.OK)
            {
                pBox_Others.Image = new Bitmap(openfile.FileName);
            }
        }

        private void pnl_Others_Paint(object sender, PaintEventArgs e)
        {
            if (pBox_Others.Image != null)
            {
                tb_ItemName.Enabled = true;
                tb_ItemPrice.Enabled = true;
            }
            else
            {
                tb_ItemName.Enabled = false;
                tb_ItemPrice.Enabled = false;
            }

            if (pBox_Others.Image != null && tb_ItemName.Text != string.Empty && tb_ItemPrice.Text != string.Empty)
            {
                btn_AddCartOthers.Enabled = true;
            }
            else if (pBox_Others.Image != null && tb_ItemName.Text == string.Empty && tb_ItemPrice.Text == string.Empty)
            {
                btn_AddCartOthers.Enabled = false;
            }
            else
            {
                btn_AddCartOthers.Enabled = false;
            }
        }
        private void tb_ItemPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void btn_AddCartOthers_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int simpan = 0;
            int simpanInt = 0;

            simpanInt = int.Parse(tb_ItemPrice.Text);
            Total = simpanInt;

            for (int i = 0; i < dtProduk.Rows.Count; i++)
            {
                if (tb_ItemName.Text == dtProduk.Rows[i][0].ToString())
                {
                    sama = true;
                    simpan = i;
                    break;
                }
                else
                {
                    sama = false;
                }
            }

            if(sama == false)
            {
                countO = 1;
                Total = 1 * simpanInt;
                dtsimpanharga.Rows.Add(Total);

                format(Total);
                dtProduk.Rows.Add(tb_ItemName.Text, countO, simpanrupiah, simpanrupiah);
            }
            else if (sama == true)
            {
                countO = Int32.Parse(dtProduk.Rows[simpan][1].ToString());
                countO++;
                Total = countO * simpanInt;

                format(Total);

                dtProduk.Rows[simpan][1] = countO;
                dtProduk.Rows[simpan][3] = simpanrupiah;

                dtsimpanharga.Rows[simpan][0] = Total;
            }

            totalharga();

            pBox_Others.Image = null;
            tb_ItemName.Text = string.Empty;
            tb_ItemPrice.Text = string.Empty;
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow dgvrPro = dgv_Produk.CurrentRow;
            int selectedrows = 0;

            if(dgv_Produk.SelectedRows.Count > 0)
            {
                selectedrows = dgv_Produk.CurrentRow.Index;
                dtsimpanharga.Rows.RemoveAt(selectedrows);
                dgv_Produk.Rows.Remove(dgvrPro);

                if (dgv_Produk.Rows.Count > 0)
                {
                    totalharga();
                }
                else if (dgv_Produk.Rows.Count == 0)
                {
                    subtotal = 0;
                    simpanharga = 0;
                    tb_SubTotal.Text = subtotal.ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                    tb_Total.Text = (subtotal + (0.1 * subtotal)).ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                }
            }
        }
    }
}
