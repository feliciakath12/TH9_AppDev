﻿namespace W9_Take_Home_New
{
    partial class Form_UNIQME
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_TShirt = new System.Windows.Forms.Panel();
            this.pBox_TShirt1 = new System.Windows.Forms.PictureBox();
            this.btn_AddCartTShirt3 = new System.Windows.Forms.Button();
            this.btn_AddCartTShirt2 = new System.Windows.Forms.Button();
            this.btn_AddCartTShirt1 = new System.Windows.Forms.Button();
            this.lb_HargaTShirtVNeck = new System.Windows.Forms.Label();
            this.lb_HargaTShirtAIRism = new System.Windows.Forms.Label();
            this.lb_HargaTShirtKerahBulat = new System.Windows.Forms.Label();
            this.lb_TShirtVNeck = new System.Windows.Forms.Label();
            this.lb_TShirtAIRism = new System.Windows.Forms.Label();
            this.lb_TShirtKerahBulat = new System.Windows.Forms.Label();
            this.pBox_TShirt3 = new System.Windows.Forms.PictureBox();
            this.pBox_TShirt2 = new System.Windows.Forms.PictureBox();
            this.tb_Total = new System.Windows.Forms.TextBox();
            this.tb_SubTotal = new System.Windows.Forms.TextBox();
            this.lb_Total = new System.Windows.Forms.Label();
            this.lb_SubTotal = new System.Windows.Forms.Label();
            this.dgv_Produk = new System.Windows.Forms.DataGridView();
            this.menuStripUniqme = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnl_Shirt = new System.Windows.Forms.Panel();
            this.pBox_Shirt1 = new System.Windows.Forms.PictureBox();
            this.btn_AddCartShirt3 = new System.Windows.Forms.Button();
            this.btn_AddCart2 = new System.Windows.Forms.Button();
            this.btn_AddCartShirt1 = new System.Windows.Forms.Button();
            this.lb_HargaCottonShirt = new System.Windows.Forms.Label();
            this.lb_HargaClassicWhiteShirt = new System.Windows.Forms.Label();
            this.lb_HargaShortSleeveShirt = new System.Windows.Forms.Label();
            this.lb_CottonShirt = new System.Windows.Forms.Label();
            this.lb_ClassicWhiteShirt = new System.Windows.Forms.Label();
            this.lb_ShortSleeveShirt = new System.Windows.Forms.Label();
            this.pBox_Shirt3 = new System.Windows.Forms.PictureBox();
            this.pBox_Shirt2 = new System.Windows.Forms.PictureBox();
            this.pnl_Pants = new System.Windows.Forms.Panel();
            this.pBox_Pants1 = new System.Windows.Forms.PictureBox();
            this.btn_AddCartPants3 = new System.Windows.Forms.Button();
            this.btn_AddCartPants2 = new System.Windows.Forms.Button();
            this.btn_AddCartPants1 = new System.Windows.Forms.Button();
            this.lb_HargaWomenPants = new System.Windows.Forms.Label();
            this.lb_HargaBlackAnklePants = new System.Windows.Forms.Label();
            this.lb_HargaLightPants = new System.Windows.Forms.Label();
            this.lb_WomenPants = new System.Windows.Forms.Label();
            this.lb_BlackAnklePants = new System.Windows.Forms.Label();
            this.lb_LightPants = new System.Windows.Forms.Label();
            this.pBox_Pants3 = new System.Windows.Forms.PictureBox();
            this.pBox_Pants2 = new System.Windows.Forms.PictureBox();
            this.pnl_LongPants = new System.Windows.Forms.Panel();
            this.pBox_LongPants1 = new System.Windows.Forms.PictureBox();
            this.btn_AddCartLongPants3 = new System.Windows.Forms.Button();
            this.btn_AddCartLongPants2 = new System.Windows.Forms.Button();
            this.btn_AddCartLongPants1 = new System.Windows.Forms.Button();
            this.lb_HargaCasualLongPants = new System.Windows.Forms.Label();
            this.lb_HargaBlackLongPants = new System.Windows.Forms.Label();
            this.lb_HargaCargoLongPants = new System.Windows.Forms.Label();
            this.lb_CasualLongPants = new System.Windows.Forms.Label();
            this.lb_BlackLongPants = new System.Windows.Forms.Label();
            this.lb_CargoLongPants = new System.Windows.Forms.Label();
            this.pBox_LongPants3 = new System.Windows.Forms.PictureBox();
            this.pBox_LongPants2 = new System.Windows.Forms.PictureBox();
            this.pnl_Shoes = new System.Windows.Forms.Panel();
            this.pBox_Shoe1 = new System.Windows.Forms.PictureBox();
            this.btn_AddCartShoe3 = new System.Windows.Forms.Button();
            this.btn_AddCartShoe2 = new System.Windows.Forms.Button();
            this.btn_AddCartShoe1 = new System.Windows.Forms.Button();
            this.lb_HargaFlatShoes = new System.Windows.Forms.Label();
            this.lb_HargaSneakersShoes = new System.Windows.Forms.Label();
            this.lb_HargaRunningShoes = new System.Windows.Forms.Label();
            this.lb_FlatShoes = new System.Windows.Forms.Label();
            this.lb_SneakersShoes = new System.Windows.Forms.Label();
            this.lb_RunningShoes = new System.Windows.Forms.Label();
            this.pBox_Shoe3 = new System.Windows.Forms.PictureBox();
            this.pBox_Shoe2 = new System.Windows.Forms.PictureBox();
            this.pnl_Jewellery = new System.Windows.Forms.Panel();
            this.btn_AddCartJewellery3 = new System.Windows.Forms.Button();
            this.btn_AddCartJewellery2 = new System.Windows.Forms.Button();
            this.lb_HargaBraceletJewellery = new System.Windows.Forms.Label();
            this.btn_AddCartJewellery1 = new System.Windows.Forms.Button();
            this.lb_HargaNecklaceJewellery = new System.Windows.Forms.Label();
            this.pBox_Jewelleries1 = new System.Windows.Forms.PictureBox();
            this.lb_HargaRingJewellery = new System.Windows.Forms.Label();
            this.pBox_Jewelleries3 = new System.Windows.Forms.PictureBox();
            this.lb_BraceletJewellery = new System.Windows.Forms.Label();
            this.pBox_Jewelleries2 = new System.Windows.Forms.PictureBox();
            this.lb_NecklaceJewellery = new System.Windows.Forms.Label();
            this.lb_RingJewellery = new System.Windows.Forms.Label();
            this.pnl_Others = new System.Windows.Forms.Panel();
            this.tb_ItemPrice = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_ItemName = new System.Windows.Forms.TextBox();
            this.btn_Upload = new System.Windows.Forms.Button();
            this.btn_AddCartOthers = new System.Windows.Forms.Button();
            this.pBox_Others = new System.Windows.Forms.PictureBox();
            this.lb_ItemName = new System.Windows.Forms.Label();
            this.lb_UploadImage = new System.Windows.Forms.Label();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.pnl_TShirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_TShirt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_TShirt3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_TShirt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Produk)).BeginInit();
            this.menuStripUniqme.SuspendLayout();
            this.pnl_Shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shirt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shirt3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shirt2)).BeginInit();
            this.pnl_Pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Pants1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Pants3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Pants2)).BeginInit();
            this.pnl_LongPants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_LongPants1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_LongPants3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_LongPants2)).BeginInit();
            this.pnl_Shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shoe1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shoe3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shoe2)).BeginInit();
            this.pnl_Jewellery.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Jewelleries1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Jewelleries3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Jewelleries2)).BeginInit();
            this.pnl_Others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Others)).BeginInit();
            this.SuspendLayout();
            // 
            // pnl_TShirt
            // 
            this.pnl_TShirt.Controls.Add(this.pBox_TShirt1);
            this.pnl_TShirt.Controls.Add(this.btn_AddCartTShirt3);
            this.pnl_TShirt.Controls.Add(this.btn_AddCartTShirt2);
            this.pnl_TShirt.Controls.Add(this.btn_AddCartTShirt1);
            this.pnl_TShirt.Controls.Add(this.lb_HargaTShirtVNeck);
            this.pnl_TShirt.Controls.Add(this.lb_HargaTShirtAIRism);
            this.pnl_TShirt.Controls.Add(this.lb_HargaTShirtKerahBulat);
            this.pnl_TShirt.Controls.Add(this.lb_TShirtVNeck);
            this.pnl_TShirt.Controls.Add(this.lb_TShirtAIRism);
            this.pnl_TShirt.Controls.Add(this.lb_TShirtKerahBulat);
            this.pnl_TShirt.Controls.Add(this.pBox_TShirt3);
            this.pnl_TShirt.Controls.Add(this.pBox_TShirt2);
            this.pnl_TShirt.Location = new System.Drawing.Point(0, 53);
            this.pnl_TShirt.Name = "pnl_TShirt";
            this.pnl_TShirt.Size = new System.Drawing.Size(557, 474);
            this.pnl_TShirt.TabIndex = 13;
            // 
            // pBox_TShirt1
            // 
            this.pBox_TShirt1.Image = global::W9_Take_Home_New.Properties.Resources.T_Shirt_Kerah_Bulat;
            this.pBox_TShirt1.Location = new System.Drawing.Point(12, 26);
            this.pBox_TShirt1.Name = "pBox_TShirt1";
            this.pBox_TShirt1.Size = new System.Drawing.Size(158, 246);
            this.pBox_TShirt1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_TShirt1.TabIndex = 12;
            this.pBox_TShirt1.TabStop = false;
            // 
            // btn_AddCartTShirt3
            // 
            this.btn_AddCartTShirt3.Location = new System.Drawing.Point(387, 353);
            this.btn_AddCartTShirt3.Name = "btn_AddCartTShirt3";
            this.btn_AddCartTShirt3.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartTShirt3.TabIndex = 11;
            this.btn_AddCartTShirt3.Text = "Add to Cart";
            this.btn_AddCartTShirt3.UseVisualStyleBackColor = true;
            this.btn_AddCartTShirt3.Click += new System.EventHandler(this.btn_AddCartTShirt3_Click);
            // 
            // btn_AddCartTShirt2
            // 
            this.btn_AddCartTShirt2.Location = new System.Drawing.Point(201, 353);
            this.btn_AddCartTShirt2.Name = "btn_AddCartTShirt2";
            this.btn_AddCartTShirt2.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartTShirt2.TabIndex = 10;
            this.btn_AddCartTShirt2.Text = "Add to Cart";
            this.btn_AddCartTShirt2.UseVisualStyleBackColor = true;
            this.btn_AddCartTShirt2.Click += new System.EventHandler(this.btn_AddCartTShirt2_Click);
            // 
            // btn_AddCartTShirt1
            // 
            this.btn_AddCartTShirt1.Location = new System.Drawing.Point(12, 353);
            this.btn_AddCartTShirt1.Name = "btn_AddCartTShirt1";
            this.btn_AddCartTShirt1.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartTShirt1.TabIndex = 9;
            this.btn_AddCartTShirt1.Text = "Add to Cart";
            this.btn_AddCartTShirt1.UseVisualStyleBackColor = true;
            this.btn_AddCartTShirt1.Click += new System.EventHandler(this.btn_AddCartTShirt1_Click);
            // 
            // lb_HargaTShirtVNeck
            // 
            this.lb_HargaTShirtVNeck.AutoSize = true;
            this.lb_HargaTShirtVNeck.Location = new System.Drawing.Point(383, 305);
            this.lb_HargaTShirtVNeck.Name = "lb_HargaTShirtVNeck";
            this.lb_HargaTShirtVNeck.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaTShirtVNeck.TabIndex = 8;
            this.lb_HargaTShirtVNeck.Text = "Rp. 170.000,-";
            // 
            // lb_HargaTShirtAIRism
            // 
            this.lb_HargaTShirtAIRism.AutoSize = true;
            this.lb_HargaTShirtAIRism.Location = new System.Drawing.Point(197, 305);
            this.lb_HargaTShirtAIRism.Name = "lb_HargaTShirtAIRism";
            this.lb_HargaTShirtAIRism.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaTShirtAIRism.TabIndex = 7;
            this.lb_HargaTShirtAIRism.Text = "Rp. 150.000,-";
            // 
            // lb_HargaTShirtKerahBulat
            // 
            this.lb_HargaTShirtKerahBulat.AutoSize = true;
            this.lb_HargaTShirtKerahBulat.Location = new System.Drawing.Point(12, 305);
            this.lb_HargaTShirtKerahBulat.Name = "lb_HargaTShirtKerahBulat";
            this.lb_HargaTShirtKerahBulat.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaTShirtKerahBulat.TabIndex = 6;
            this.lb_HargaTShirtKerahBulat.Text = "Rp. 120.000,-";
            // 
            // lb_TShirtVNeck
            // 
            this.lb_TShirtVNeck.AutoSize = true;
            this.lb_TShirtVNeck.Location = new System.Drawing.Point(383, 280);
            this.lb_TShirtVNeck.Name = "lb_TShirtVNeck";
            this.lb_TShirtVNeck.Size = new System.Drawing.Size(107, 20);
            this.lb_TShirtVNeck.TabIndex = 5;
            this.lb_TShirtVNeck.Text = "T-Shirt VNeck";
            // 
            // lb_TShirtAIRism
            // 
            this.lb_TShirtAIRism.AutoSize = true;
            this.lb_TShirtAIRism.Location = new System.Drawing.Point(197, 280);
            this.lb_TShirtAIRism.Name = "lb_TShirtAIRism";
            this.lb_TShirtAIRism.Size = new System.Drawing.Size(112, 20);
            this.lb_TShirtAIRism.TabIndex = 4;
            this.lb_TShirtAIRism.Text = "AIRism T-Shirt";
            // 
            // lb_TShirtKerahBulat
            // 
            this.lb_TShirtKerahBulat.AutoSize = true;
            this.lb_TShirtKerahBulat.Location = new System.Drawing.Point(12, 280);
            this.lb_TShirtKerahBulat.Name = "lb_TShirtKerahBulat";
            this.lb_TShirtKerahBulat.Size = new System.Drawing.Size(143, 20);
            this.lb_TShirtKerahBulat.TabIndex = 3;
            this.lb_TShirtKerahBulat.Text = "T-Shirt Kerah Bulat";
            // 
            // pBox_TShirt3
            // 
            this.pBox_TShirt3.Image = global::W9_Take_Home_New.Properties.Resources.T_Shirt_Vneck;
            this.pBox_TShirt3.Location = new System.Drawing.Point(384, 26);
            this.pBox_TShirt3.Name = "pBox_TShirt3";
            this.pBox_TShirt3.Size = new System.Drawing.Size(158, 246);
            this.pBox_TShirt3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_TShirt3.TabIndex = 2;
            this.pBox_TShirt3.TabStop = false;
            // 
            // pBox_TShirt2
            // 
            this.pBox_TShirt2.Image = global::W9_Take_Home_New.Properties.Resources.AIRism_T_Shirt;
            this.pBox_TShirt2.Location = new System.Drawing.Point(198, 26);
            this.pBox_TShirt2.Name = "pBox_TShirt2";
            this.pBox_TShirt2.Size = new System.Drawing.Size(158, 246);
            this.pBox_TShirt2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_TShirt2.TabIndex = 1;
            this.pBox_TShirt2.TabStop = false;
            // 
            // tb_Total
            // 
            this.tb_Total.Location = new System.Drawing.Point(863, 429);
            this.tb_Total.Name = "tb_Total";
            this.tb_Total.ReadOnly = true;
            this.tb_Total.Size = new System.Drawing.Size(156, 26);
            this.tb_Total.TabIndex = 12;
            // 
            // tb_SubTotal
            // 
            this.tb_SubTotal.Location = new System.Drawing.Point(863, 391);
            this.tb_SubTotal.Name = "tb_SubTotal";
            this.tb_SubTotal.ReadOnly = true;
            this.tb_SubTotal.Size = new System.Drawing.Size(156, 26);
            this.tb_SubTotal.TabIndex = 11;
            // 
            // lb_Total
            // 
            this.lb_Total.AutoSize = true;
            this.lb_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Total.Location = new System.Drawing.Point(753, 423);
            this.lb_Total.Name = "lb_Total";
            this.lb_Total.Size = new System.Drawing.Size(92, 32);
            this.lb_Total.TabIndex = 10;
            this.lb_Total.Text = "Total:";
            // 
            // lb_SubTotal
            // 
            this.lb_SubTotal.AutoSize = true;
            this.lb_SubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_SubTotal.Location = new System.Drawing.Point(689, 385);
            this.lb_SubTotal.Name = "lb_SubTotal";
            this.lb_SubTotal.Size = new System.Drawing.Size(156, 32);
            this.lb_SubTotal.TabIndex = 9;
            this.lb_SubTotal.Text = "Sub-Total:";
            // 
            // dgv_Produk
            // 
            this.dgv_Produk.AllowUserToAddRows = false;
            this.dgv_Produk.AllowUserToDeleteRows = false;
            this.dgv_Produk.AllowUserToResizeColumns = false;
            this.dgv_Produk.AllowUserToResizeRows = false;
            this.dgv_Produk.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Produk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Produk.Location = new System.Drawing.Point(573, 53);
            this.dgv_Produk.Name = "dgv_Produk";
            this.dgv_Produk.RowHeadersVisible = false;
            this.dgv_Produk.RowHeadersWidth = 62;
            this.dgv_Produk.RowTemplate.Height = 28;
            this.dgv_Produk.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_Produk.Size = new System.Drawing.Size(446, 317);
            this.dgv_Produk.TabIndex = 8;
            // 
            // menuStripUniqme
            // 
            this.menuStripUniqme.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStripUniqme.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStripUniqme.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStripUniqme.Location = new System.Drawing.Point(0, 0);
            this.menuStripUniqme.Name = "menuStripUniqme";
            this.menuStripUniqme.Size = new System.Drawing.Size(1037, 33);
            this.menuStripUniqme.TabIndex = 7;
            this.menuStripUniqme.Text = "menuStripUniqme";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(102, 29);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(133, 29);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(119, 29);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(81, 29);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // pnl_Shirt
            // 
            this.pnl_Shirt.Controls.Add(this.pBox_Shirt1);
            this.pnl_Shirt.Controls.Add(this.btn_AddCartShirt3);
            this.pnl_Shirt.Controls.Add(this.btn_AddCart2);
            this.pnl_Shirt.Controls.Add(this.btn_AddCartShirt1);
            this.pnl_Shirt.Controls.Add(this.lb_HargaCottonShirt);
            this.pnl_Shirt.Controls.Add(this.lb_HargaClassicWhiteShirt);
            this.pnl_Shirt.Controls.Add(this.lb_HargaShortSleeveShirt);
            this.pnl_Shirt.Controls.Add(this.lb_CottonShirt);
            this.pnl_Shirt.Controls.Add(this.lb_ClassicWhiteShirt);
            this.pnl_Shirt.Controls.Add(this.lb_ShortSleeveShirt);
            this.pnl_Shirt.Controls.Add(this.pBox_Shirt3);
            this.pnl_Shirt.Controls.Add(this.pBox_Shirt2);
            this.pnl_Shirt.Location = new System.Drawing.Point(0, 53);
            this.pnl_Shirt.Name = "pnl_Shirt";
            this.pnl_Shirt.Size = new System.Drawing.Size(557, 474);
            this.pnl_Shirt.TabIndex = 14;
            // 
            // pBox_Shirt1
            // 
            this.pBox_Shirt1.Image = global::W9_Take_Home_New.Properties.Resources.Short_Sleeve_Shirt;
            this.pBox_Shirt1.Location = new System.Drawing.Point(12, 26);
            this.pBox_Shirt1.Name = "pBox_Shirt1";
            this.pBox_Shirt1.Size = new System.Drawing.Size(158, 246);
            this.pBox_Shirt1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Shirt1.TabIndex = 12;
            this.pBox_Shirt1.TabStop = false;
            // 
            // btn_AddCartShirt3
            // 
            this.btn_AddCartShirt3.Location = new System.Drawing.Point(387, 353);
            this.btn_AddCartShirt3.Name = "btn_AddCartShirt3";
            this.btn_AddCartShirt3.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartShirt3.TabIndex = 11;
            this.btn_AddCartShirt3.Text = "Add to Cart";
            this.btn_AddCartShirt3.UseVisualStyleBackColor = true;
            this.btn_AddCartShirt3.Click += new System.EventHandler(this.btn_AddCartShirt3_Click);
            // 
            // btn_AddCart2
            // 
            this.btn_AddCart2.Location = new System.Drawing.Point(201, 353);
            this.btn_AddCart2.Name = "btn_AddCart2";
            this.btn_AddCart2.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCart2.TabIndex = 10;
            this.btn_AddCart2.Text = "Add to Cart";
            this.btn_AddCart2.UseVisualStyleBackColor = true;
            this.btn_AddCart2.Click += new System.EventHandler(this.btn_AddCart2_Click);
            // 
            // btn_AddCartShirt1
            // 
            this.btn_AddCartShirt1.Location = new System.Drawing.Point(12, 353);
            this.btn_AddCartShirt1.Name = "btn_AddCartShirt1";
            this.btn_AddCartShirt1.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartShirt1.TabIndex = 9;
            this.btn_AddCartShirt1.Text = "Add to Cart";
            this.btn_AddCartShirt1.UseVisualStyleBackColor = true;
            this.btn_AddCartShirt1.Click += new System.EventHandler(this.btn_AddCartShirt1_Click);
            // 
            // lb_HargaCottonShirt
            // 
            this.lb_HargaCottonShirt.AutoSize = true;
            this.lb_HargaCottonShirt.Location = new System.Drawing.Point(383, 305);
            this.lb_HargaCottonShirt.Name = "lb_HargaCottonShirt";
            this.lb_HargaCottonShirt.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaCottonShirt.TabIndex = 8;
            this.lb_HargaCottonShirt.Text = "Rp. 220.000,-";
            // 
            // lb_HargaClassicWhiteShirt
            // 
            this.lb_HargaClassicWhiteShirt.AutoSize = true;
            this.lb_HargaClassicWhiteShirt.Location = new System.Drawing.Point(197, 305);
            this.lb_HargaClassicWhiteShirt.Name = "lb_HargaClassicWhiteShirt";
            this.lb_HargaClassicWhiteShirt.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaClassicWhiteShirt.TabIndex = 7;
            this.lb_HargaClassicWhiteShirt.Text = "Rp. 190.000,-";
            // 
            // lb_HargaShortSleeveShirt
            // 
            this.lb_HargaShortSleeveShirt.AutoSize = true;
            this.lb_HargaShortSleeveShirt.Location = new System.Drawing.Point(12, 305);
            this.lb_HargaShortSleeveShirt.Name = "lb_HargaShortSleeveShirt";
            this.lb_HargaShortSleeveShirt.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaShortSleeveShirt.TabIndex = 6;
            this.lb_HargaShortSleeveShirt.Text = "Rp. 200.000,-";
            // 
            // lb_CottonShirt
            // 
            this.lb_CottonShirt.AutoSize = true;
            this.lb_CottonShirt.Location = new System.Drawing.Point(383, 280);
            this.lb_CottonShirt.Name = "lb_CottonShirt";
            this.lb_CottonShirt.Size = new System.Drawing.Size(94, 20);
            this.lb_CottonShirt.TabIndex = 5;
            this.lb_CottonShirt.Text = "Cotton Shirt";
            // 
            // lb_ClassicWhiteShirt
            // 
            this.lb_ClassicWhiteShirt.AutoSize = true;
            this.lb_ClassicWhiteShirt.Location = new System.Drawing.Point(197, 280);
            this.lb_ClassicWhiteShirt.Name = "lb_ClassicWhiteShirt";
            this.lb_ClassicWhiteShirt.Size = new System.Drawing.Size(141, 20);
            this.lb_ClassicWhiteShirt.TabIndex = 4;
            this.lb_ClassicWhiteShirt.Text = "Classic White Shirt";
            // 
            // lb_ShortSleeveShirt
            // 
            this.lb_ShortSleeveShirt.AutoSize = true;
            this.lb_ShortSleeveShirt.Location = new System.Drawing.Point(12, 280);
            this.lb_ShortSleeveShirt.Name = "lb_ShortSleeveShirt";
            this.lb_ShortSleeveShirt.Size = new System.Drawing.Size(137, 20);
            this.lb_ShortSleeveShirt.TabIndex = 3;
            this.lb_ShortSleeveShirt.Text = "Short Sleeve Shirt";
            // 
            // pBox_Shirt3
            // 
            this.pBox_Shirt3.Image = global::W9_Take_Home_New.Properties.Resources.Cotton_Shirt;
            this.pBox_Shirt3.Location = new System.Drawing.Point(384, 26);
            this.pBox_Shirt3.Name = "pBox_Shirt3";
            this.pBox_Shirt3.Size = new System.Drawing.Size(158, 246);
            this.pBox_Shirt3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Shirt3.TabIndex = 2;
            this.pBox_Shirt3.TabStop = false;
            // 
            // pBox_Shirt2
            // 
            this.pBox_Shirt2.Image = global::W9_Take_Home_New.Properties.Resources.Classic_White_Shirt;
            this.pBox_Shirt2.Location = new System.Drawing.Point(198, 26);
            this.pBox_Shirt2.Name = "pBox_Shirt2";
            this.pBox_Shirt2.Size = new System.Drawing.Size(158, 246);
            this.pBox_Shirt2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Shirt2.TabIndex = 1;
            this.pBox_Shirt2.TabStop = false;
            // 
            // pnl_Pants
            // 
            this.pnl_Pants.Controls.Add(this.pBox_Pants1);
            this.pnl_Pants.Controls.Add(this.btn_AddCartPants3);
            this.pnl_Pants.Controls.Add(this.btn_AddCartPants2);
            this.pnl_Pants.Controls.Add(this.btn_AddCartPants1);
            this.pnl_Pants.Controls.Add(this.lb_HargaWomenPants);
            this.pnl_Pants.Controls.Add(this.lb_HargaBlackAnklePants);
            this.pnl_Pants.Controls.Add(this.lb_HargaLightPants);
            this.pnl_Pants.Controls.Add(this.lb_WomenPants);
            this.pnl_Pants.Controls.Add(this.lb_BlackAnklePants);
            this.pnl_Pants.Controls.Add(this.lb_LightPants);
            this.pnl_Pants.Controls.Add(this.pBox_Pants3);
            this.pnl_Pants.Controls.Add(this.pBox_Pants2);
            this.pnl_Pants.Location = new System.Drawing.Point(0, 53);
            this.pnl_Pants.Name = "pnl_Pants";
            this.pnl_Pants.Size = new System.Drawing.Size(557, 474);
            this.pnl_Pants.TabIndex = 15;
            // 
            // pBox_Pants1
            // 
            this.pBox_Pants1.Image = global::W9_Take_Home_New.Properties.Resources.Adventure_Light_Pants;
            this.pBox_Pants1.Location = new System.Drawing.Point(12, 26);
            this.pBox_Pants1.Name = "pBox_Pants1";
            this.pBox_Pants1.Size = new System.Drawing.Size(158, 246);
            this.pBox_Pants1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Pants1.TabIndex = 12;
            this.pBox_Pants1.TabStop = false;
            // 
            // btn_AddCartPants3
            // 
            this.btn_AddCartPants3.Location = new System.Drawing.Point(387, 353);
            this.btn_AddCartPants3.Name = "btn_AddCartPants3";
            this.btn_AddCartPants3.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartPants3.TabIndex = 11;
            this.btn_AddCartPants3.Text = "Add to Cart";
            this.btn_AddCartPants3.UseVisualStyleBackColor = true;
            this.btn_AddCartPants3.Click += new System.EventHandler(this.btn_AddCartPants3_Click);
            // 
            // btn_AddCartPants2
            // 
            this.btn_AddCartPants2.Location = new System.Drawing.Point(201, 353);
            this.btn_AddCartPants2.Name = "btn_AddCartPants2";
            this.btn_AddCartPants2.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartPants2.TabIndex = 10;
            this.btn_AddCartPants2.Text = "Add to Cart";
            this.btn_AddCartPants2.UseVisualStyleBackColor = true;
            this.btn_AddCartPants2.Click += new System.EventHandler(this.btn_AddCartPants2_Click);
            // 
            // btn_AddCartPants1
            // 
            this.btn_AddCartPants1.Location = new System.Drawing.Point(12, 353);
            this.btn_AddCartPants1.Name = "btn_AddCartPants1";
            this.btn_AddCartPants1.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartPants1.TabIndex = 9;
            this.btn_AddCartPants1.Text = "Add to Cart";
            this.btn_AddCartPants1.UseVisualStyleBackColor = true;
            this.btn_AddCartPants1.Click += new System.EventHandler(this.btn_AddCartPants1_Click);
            // 
            // lb_HargaWomenPants
            // 
            this.lb_HargaWomenPants.AutoSize = true;
            this.lb_HargaWomenPants.Location = new System.Drawing.Point(383, 305);
            this.lb_HargaWomenPants.Name = "lb_HargaWomenPants";
            this.lb_HargaWomenPants.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaWomenPants.TabIndex = 8;
            this.lb_HargaWomenPants.Text = "Rp. 250.000,-";
            // 
            // lb_HargaBlackAnklePants
            // 
            this.lb_HargaBlackAnklePants.AutoSize = true;
            this.lb_HargaBlackAnklePants.Location = new System.Drawing.Point(197, 305);
            this.lb_HargaBlackAnklePants.Name = "lb_HargaBlackAnklePants";
            this.lb_HargaBlackAnklePants.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaBlackAnklePants.TabIndex = 7;
            this.lb_HargaBlackAnklePants.Text = "Rp. 200.000,-";
            // 
            // lb_HargaLightPants
            // 
            this.lb_HargaLightPants.AutoSize = true;
            this.lb_HargaLightPants.Location = new System.Drawing.Point(12, 305);
            this.lb_HargaLightPants.Name = "lb_HargaLightPants";
            this.lb_HargaLightPants.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaLightPants.TabIndex = 6;
            this.lb_HargaLightPants.Text = "Rp. 160.000,-";
            // 
            // lb_WomenPants
            // 
            this.lb_WomenPants.AutoSize = true;
            this.lb_WomenPants.Location = new System.Drawing.Point(383, 280);
            this.lb_WomenPants.Name = "lb_WomenPants";
            this.lb_WomenPants.Size = new System.Drawing.Size(109, 20);
            this.lb_WomenPants.TabIndex = 5;
            this.lb_WomenPants.Text = "Women Pants";
            // 
            // lb_BlackAnklePants
            // 
            this.lb_BlackAnklePants.AutoSize = true;
            this.lb_BlackAnklePants.Location = new System.Drawing.Point(197, 280);
            this.lb_BlackAnklePants.Name = "lb_BlackAnklePants";
            this.lb_BlackAnklePants.Size = new System.Drawing.Size(137, 20);
            this.lb_BlackAnklePants.TabIndex = 4;
            this.lb_BlackAnklePants.Text = "Black Ankle Pants";
            // 
            // lb_LightPants
            // 
            this.lb_LightPants.AutoSize = true;
            this.lb_LightPants.Location = new System.Drawing.Point(12, 280);
            this.lb_LightPants.Name = "lb_LightPants";
            this.lb_LightPants.Size = new System.Drawing.Size(89, 20);
            this.lb_LightPants.TabIndex = 3;
            this.lb_LightPants.Text = "Light Pants";
            // 
            // pBox_Pants3
            // 
            this.pBox_Pants3.Image = global::W9_Take_Home_New.Properties.Resources.Women_Pants;
            this.pBox_Pants3.Location = new System.Drawing.Point(384, 26);
            this.pBox_Pants3.Name = "pBox_Pants3";
            this.pBox_Pants3.Size = new System.Drawing.Size(158, 246);
            this.pBox_Pants3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Pants3.TabIndex = 2;
            this.pBox_Pants3.TabStop = false;
            // 
            // pBox_Pants2
            // 
            this.pBox_Pants2.Image = global::W9_Take_Home_New.Properties.Resources.Black_Ankle_Pants;
            this.pBox_Pants2.Location = new System.Drawing.Point(198, 26);
            this.pBox_Pants2.Name = "pBox_Pants2";
            this.pBox_Pants2.Size = new System.Drawing.Size(158, 246);
            this.pBox_Pants2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Pants2.TabIndex = 1;
            this.pBox_Pants2.TabStop = false;
            // 
            // pnl_LongPants
            // 
            this.pnl_LongPants.Controls.Add(this.pBox_LongPants1);
            this.pnl_LongPants.Controls.Add(this.btn_AddCartLongPants3);
            this.pnl_LongPants.Controls.Add(this.btn_AddCartLongPants2);
            this.pnl_LongPants.Controls.Add(this.btn_AddCartLongPants1);
            this.pnl_LongPants.Controls.Add(this.lb_HargaCasualLongPants);
            this.pnl_LongPants.Controls.Add(this.lb_HargaBlackLongPants);
            this.pnl_LongPants.Controls.Add(this.lb_HargaCargoLongPants);
            this.pnl_LongPants.Controls.Add(this.lb_CasualLongPants);
            this.pnl_LongPants.Controls.Add(this.lb_BlackLongPants);
            this.pnl_LongPants.Controls.Add(this.lb_CargoLongPants);
            this.pnl_LongPants.Controls.Add(this.pBox_LongPants3);
            this.pnl_LongPants.Controls.Add(this.pBox_LongPants2);
            this.pnl_LongPants.Location = new System.Drawing.Point(0, 53);
            this.pnl_LongPants.Name = "pnl_LongPants";
            this.pnl_LongPants.Size = new System.Drawing.Size(557, 474);
            this.pnl_LongPants.TabIndex = 16;
            // 
            // pBox_LongPants1
            // 
            this.pBox_LongPants1.Image = global::W9_Take_Home_New.Properties.Resources.Cargo_Long_Pants;
            this.pBox_LongPants1.Location = new System.Drawing.Point(12, 26);
            this.pBox_LongPants1.Name = "pBox_LongPants1";
            this.pBox_LongPants1.Size = new System.Drawing.Size(158, 246);
            this.pBox_LongPants1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_LongPants1.TabIndex = 12;
            this.pBox_LongPants1.TabStop = false;
            // 
            // btn_AddCartLongPants3
            // 
            this.btn_AddCartLongPants3.Location = new System.Drawing.Point(387, 353);
            this.btn_AddCartLongPants3.Name = "btn_AddCartLongPants3";
            this.btn_AddCartLongPants3.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartLongPants3.TabIndex = 11;
            this.btn_AddCartLongPants3.Text = "Add to Cart";
            this.btn_AddCartLongPants3.UseVisualStyleBackColor = true;
            this.btn_AddCartLongPants3.Click += new System.EventHandler(this.btn_AddCartLongPants3_Click);
            // 
            // btn_AddCartLongPants2
            // 
            this.btn_AddCartLongPants2.Location = new System.Drawing.Point(201, 353);
            this.btn_AddCartLongPants2.Name = "btn_AddCartLongPants2";
            this.btn_AddCartLongPants2.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartLongPants2.TabIndex = 10;
            this.btn_AddCartLongPants2.Text = "Add to Cart";
            this.btn_AddCartLongPants2.UseVisualStyleBackColor = true;
            this.btn_AddCartLongPants2.Click += new System.EventHandler(this.btn_AddCartLongPants2_Click);
            // 
            // btn_AddCartLongPants1
            // 
            this.btn_AddCartLongPants1.Location = new System.Drawing.Point(12, 353);
            this.btn_AddCartLongPants1.Name = "btn_AddCartLongPants1";
            this.btn_AddCartLongPants1.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartLongPants1.TabIndex = 9;
            this.btn_AddCartLongPants1.Text = "Add to Cart";
            this.btn_AddCartLongPants1.UseVisualStyleBackColor = true;
            this.btn_AddCartLongPants1.Click += new System.EventHandler(this.btn_AddCartLongPants1_Click);
            // 
            // lb_HargaCasualLongPants
            // 
            this.lb_HargaCasualLongPants.AutoSize = true;
            this.lb_HargaCasualLongPants.Location = new System.Drawing.Point(383, 305);
            this.lb_HargaCasualLongPants.Name = "lb_HargaCasualLongPants";
            this.lb_HargaCasualLongPants.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaCasualLongPants.TabIndex = 8;
            this.lb_HargaCasualLongPants.Text = "Rp. 230.000,-";
            // 
            // lb_HargaBlackLongPants
            // 
            this.lb_HargaBlackLongPants.AutoSize = true;
            this.lb_HargaBlackLongPants.Location = new System.Drawing.Point(197, 305);
            this.lb_HargaBlackLongPants.Name = "lb_HargaBlackLongPants";
            this.lb_HargaBlackLongPants.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaBlackLongPants.TabIndex = 7;
            this.lb_HargaBlackLongPants.Text = "Rp. 180.000,-";
            // 
            // lb_HargaCargoLongPants
            // 
            this.lb_HargaCargoLongPants.AutoSize = true;
            this.lb_HargaCargoLongPants.Location = new System.Drawing.Point(12, 305);
            this.lb_HargaCargoLongPants.Name = "lb_HargaCargoLongPants";
            this.lb_HargaCargoLongPants.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaCargoLongPants.TabIndex = 6;
            this.lb_HargaCargoLongPants.Text = "Rp. 240.000,-";
            // 
            // lb_CasualLongPants
            // 
            this.lb_CasualLongPants.AutoSize = true;
            this.lb_CasualLongPants.Location = new System.Drawing.Point(383, 280);
            this.lb_CasualLongPants.Name = "lb_CasualLongPants";
            this.lb_CasualLongPants.Size = new System.Drawing.Size(143, 20);
            this.lb_CasualLongPants.TabIndex = 5;
            this.lb_CasualLongPants.Text = "Casual Long Pants";
            // 
            // lb_BlackLongPants
            // 
            this.lb_BlackLongPants.AutoSize = true;
            this.lb_BlackLongPants.Location = new System.Drawing.Point(197, 280);
            this.lb_BlackLongPants.Name = "lb_BlackLongPants";
            this.lb_BlackLongPants.Size = new System.Drawing.Size(133, 20);
            this.lb_BlackLongPants.TabIndex = 4;
            this.lb_BlackLongPants.Text = "Black Long Pants";
            // 
            // lb_CargoLongPants
            // 
            this.lb_CargoLongPants.AutoSize = true;
            this.lb_CargoLongPants.Location = new System.Drawing.Point(12, 280);
            this.lb_CargoLongPants.Name = "lb_CargoLongPants";
            this.lb_CargoLongPants.Size = new System.Drawing.Size(137, 20);
            this.lb_CargoLongPants.TabIndex = 3;
            this.lb_CargoLongPants.Text = "Cargo Long Pants";
            // 
            // pBox_LongPants3
            // 
            this.pBox_LongPants3.Image = global::W9_Take_Home_New.Properties.Resources.Casual_Long_Pants;
            this.pBox_LongPants3.Location = new System.Drawing.Point(384, 26);
            this.pBox_LongPants3.Name = "pBox_LongPants3";
            this.pBox_LongPants3.Size = new System.Drawing.Size(158, 246);
            this.pBox_LongPants3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_LongPants3.TabIndex = 2;
            this.pBox_LongPants3.TabStop = false;
            // 
            // pBox_LongPants2
            // 
            this.pBox_LongPants2.Image = global::W9_Take_Home_New.Properties.Resources.Black_Long_Pants;
            this.pBox_LongPants2.Location = new System.Drawing.Point(198, 26);
            this.pBox_LongPants2.Name = "pBox_LongPants2";
            this.pBox_LongPants2.Size = new System.Drawing.Size(158, 246);
            this.pBox_LongPants2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_LongPants2.TabIndex = 1;
            this.pBox_LongPants2.TabStop = false;
            // 
            // pnl_Shoes
            // 
            this.pnl_Shoes.Controls.Add(this.pBox_Shoe1);
            this.pnl_Shoes.Controls.Add(this.btn_AddCartShoe3);
            this.pnl_Shoes.Controls.Add(this.btn_AddCartShoe2);
            this.pnl_Shoes.Controls.Add(this.btn_AddCartShoe1);
            this.pnl_Shoes.Controls.Add(this.lb_HargaFlatShoes);
            this.pnl_Shoes.Controls.Add(this.lb_HargaSneakersShoes);
            this.pnl_Shoes.Controls.Add(this.lb_HargaRunningShoes);
            this.pnl_Shoes.Controls.Add(this.lb_FlatShoes);
            this.pnl_Shoes.Controls.Add(this.lb_SneakersShoes);
            this.pnl_Shoes.Controls.Add(this.lb_RunningShoes);
            this.pnl_Shoes.Controls.Add(this.pBox_Shoe3);
            this.pnl_Shoes.Controls.Add(this.pBox_Shoe2);
            this.pnl_Shoes.Location = new System.Drawing.Point(0, 53);
            this.pnl_Shoes.Name = "pnl_Shoes";
            this.pnl_Shoes.Size = new System.Drawing.Size(557, 474);
            this.pnl_Shoes.TabIndex = 17;
            // 
            // pBox_Shoe1
            // 
            this.pBox_Shoe1.Image = global::W9_Take_Home_New.Properties.Resources.Running_Shoes;
            this.pBox_Shoe1.Location = new System.Drawing.Point(12, 26);
            this.pBox_Shoe1.Name = "pBox_Shoe1";
            this.pBox_Shoe1.Size = new System.Drawing.Size(158, 246);
            this.pBox_Shoe1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Shoe1.TabIndex = 12;
            this.pBox_Shoe1.TabStop = false;
            // 
            // btn_AddCartShoe3
            // 
            this.btn_AddCartShoe3.Location = new System.Drawing.Point(387, 353);
            this.btn_AddCartShoe3.Name = "btn_AddCartShoe3";
            this.btn_AddCartShoe3.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartShoe3.TabIndex = 11;
            this.btn_AddCartShoe3.Text = "Add to Cart";
            this.btn_AddCartShoe3.UseVisualStyleBackColor = true;
            this.btn_AddCartShoe3.Click += new System.EventHandler(this.btn_AddCartShoe3_Click);
            // 
            // btn_AddCartShoe2
            // 
            this.btn_AddCartShoe2.Location = new System.Drawing.Point(201, 353);
            this.btn_AddCartShoe2.Name = "btn_AddCartShoe2";
            this.btn_AddCartShoe2.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartShoe2.TabIndex = 10;
            this.btn_AddCartShoe2.Text = "Add to Cart";
            this.btn_AddCartShoe2.UseVisualStyleBackColor = true;
            this.btn_AddCartShoe2.Click += new System.EventHandler(this.btn_AddCartShoe2_Click);
            // 
            // btn_AddCartShoe1
            // 
            this.btn_AddCartShoe1.Location = new System.Drawing.Point(12, 353);
            this.btn_AddCartShoe1.Name = "btn_AddCartShoe1";
            this.btn_AddCartShoe1.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartShoe1.TabIndex = 9;
            this.btn_AddCartShoe1.Text = "Add to Cart";
            this.btn_AddCartShoe1.UseVisualStyleBackColor = true;
            this.btn_AddCartShoe1.Click += new System.EventHandler(this.btn_AddCartShoe1_Click);
            // 
            // lb_HargaFlatShoes
            // 
            this.lb_HargaFlatShoes.AutoSize = true;
            this.lb_HargaFlatShoes.Location = new System.Drawing.Point(383, 305);
            this.lb_HargaFlatShoes.Name = "lb_HargaFlatShoes";
            this.lb_HargaFlatShoes.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaFlatShoes.TabIndex = 8;
            this.lb_HargaFlatShoes.Text = "Rp. 320.000,-";
            // 
            // lb_HargaSneakersShoes
            // 
            this.lb_HargaSneakersShoes.AutoSize = true;
            this.lb_HargaSneakersShoes.Location = new System.Drawing.Point(197, 305);
            this.lb_HargaSneakersShoes.Name = "lb_HargaSneakersShoes";
            this.lb_HargaSneakersShoes.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaSneakersShoes.TabIndex = 7;
            this.lb_HargaSneakersShoes.Text = "Rp. 290.000,-";
            // 
            // lb_HargaRunningShoes
            // 
            this.lb_HargaRunningShoes.AutoSize = true;
            this.lb_HargaRunningShoes.Location = new System.Drawing.Point(12, 305);
            this.lb_HargaRunningShoes.Name = "lb_HargaRunningShoes";
            this.lb_HargaRunningShoes.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaRunningShoes.TabIndex = 6;
            this.lb_HargaRunningShoes.Text = "Rp. 300.000,-";
            // 
            // lb_FlatShoes
            // 
            this.lb_FlatShoes.AutoSize = true;
            this.lb_FlatShoes.Location = new System.Drawing.Point(383, 280);
            this.lb_FlatShoes.Name = "lb_FlatShoes";
            this.lb_FlatShoes.Size = new System.Drawing.Size(86, 20);
            this.lb_FlatShoes.TabIndex = 5;
            this.lb_FlatShoes.Text = "Flat Shoes";
            // 
            // lb_SneakersShoes
            // 
            this.lb_SneakersShoes.AutoSize = true;
            this.lb_SneakersShoes.Location = new System.Drawing.Point(197, 280);
            this.lb_SneakersShoes.Name = "lb_SneakersShoes";
            this.lb_SneakersShoes.Size = new System.Drawing.Size(127, 20);
            this.lb_SneakersShoes.TabIndex = 4;
            this.lb_SneakersShoes.Text = "Sneakers Shoes";
            // 
            // lb_RunningShoes
            // 
            this.lb_RunningShoes.AutoSize = true;
            this.lb_RunningShoes.Location = new System.Drawing.Point(12, 280);
            this.lb_RunningShoes.Name = "lb_RunningShoes";
            this.lb_RunningShoes.Size = new System.Drawing.Size(119, 20);
            this.lb_RunningShoes.TabIndex = 3;
            this.lb_RunningShoes.Text = "Running Shoes";
            // 
            // pBox_Shoe3
            // 
            this.pBox_Shoe3.Image = global::W9_Take_Home_New.Properties.Resources.Flat_Shoes;
            this.pBox_Shoe3.Location = new System.Drawing.Point(384, 26);
            this.pBox_Shoe3.Name = "pBox_Shoe3";
            this.pBox_Shoe3.Size = new System.Drawing.Size(158, 246);
            this.pBox_Shoe3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Shoe3.TabIndex = 2;
            this.pBox_Shoe3.TabStop = false;
            // 
            // pBox_Shoe2
            // 
            this.pBox_Shoe2.Image = global::W9_Take_Home_New.Properties.Resources.Sneakers_Shoes;
            this.pBox_Shoe2.Location = new System.Drawing.Point(198, 26);
            this.pBox_Shoe2.Name = "pBox_Shoe2";
            this.pBox_Shoe2.Size = new System.Drawing.Size(158, 246);
            this.pBox_Shoe2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Shoe2.TabIndex = 1;
            this.pBox_Shoe2.TabStop = false;
            // 
            // pnl_Jewellery
            // 
            this.pnl_Jewellery.Controls.Add(this.btn_AddCartJewellery3);
            this.pnl_Jewellery.Controls.Add(this.btn_AddCartJewellery2);
            this.pnl_Jewellery.Controls.Add(this.lb_HargaBraceletJewellery);
            this.pnl_Jewellery.Controls.Add(this.btn_AddCartJewellery1);
            this.pnl_Jewellery.Controls.Add(this.lb_HargaNecklaceJewellery);
            this.pnl_Jewellery.Controls.Add(this.pBox_Jewelleries1);
            this.pnl_Jewellery.Controls.Add(this.lb_HargaRingJewellery);
            this.pnl_Jewellery.Controls.Add(this.pBox_Jewelleries3);
            this.pnl_Jewellery.Controls.Add(this.lb_BraceletJewellery);
            this.pnl_Jewellery.Controls.Add(this.pBox_Jewelleries2);
            this.pnl_Jewellery.Controls.Add(this.lb_NecklaceJewellery);
            this.pnl_Jewellery.Controls.Add(this.lb_RingJewellery);
            this.pnl_Jewellery.Location = new System.Drawing.Point(0, 53);
            this.pnl_Jewellery.Name = "pnl_Jewellery";
            this.pnl_Jewellery.Size = new System.Drawing.Size(557, 474);
            this.pnl_Jewellery.TabIndex = 13;
            // 
            // btn_AddCartJewellery3
            // 
            this.btn_AddCartJewellery3.Location = new System.Drawing.Point(387, 353);
            this.btn_AddCartJewellery3.Name = "btn_AddCartJewellery3";
            this.btn_AddCartJewellery3.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartJewellery3.TabIndex = 15;
            this.btn_AddCartJewellery3.Text = "Add to Cart";
            this.btn_AddCartJewellery3.UseVisualStyleBackColor = true;
            this.btn_AddCartJewellery3.Click += new System.EventHandler(this.btn_AddCartJewellery3_Click);
            // 
            // btn_AddCartJewellery2
            // 
            this.btn_AddCartJewellery2.Location = new System.Drawing.Point(201, 353);
            this.btn_AddCartJewellery2.Name = "btn_AddCartJewellery2";
            this.btn_AddCartJewellery2.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartJewellery2.TabIndex = 14;
            this.btn_AddCartJewellery2.Text = "Add to Cart";
            this.btn_AddCartJewellery2.UseVisualStyleBackColor = true;
            this.btn_AddCartJewellery2.Click += new System.EventHandler(this.btn_AddCartJewellery2_Click);
            // 
            // lb_HargaBraceletJewellery
            // 
            this.lb_HargaBraceletJewellery.AutoSize = true;
            this.lb_HargaBraceletJewellery.Location = new System.Drawing.Point(383, 305);
            this.lb_HargaBraceletJewellery.Name = "lb_HargaBraceletJewellery";
            this.lb_HargaBraceletJewellery.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaBraceletJewellery.TabIndex = 18;
            this.lb_HargaBraceletJewellery.Text = "Rp. 500.000,-";
            // 
            // btn_AddCartJewellery1
            // 
            this.btn_AddCartJewellery1.Location = new System.Drawing.Point(12, 353);
            this.btn_AddCartJewellery1.Name = "btn_AddCartJewellery1";
            this.btn_AddCartJewellery1.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartJewellery1.TabIndex = 13;
            this.btn_AddCartJewellery1.Text = "Add to Cart";
            this.btn_AddCartJewellery1.UseVisualStyleBackColor = true;
            this.btn_AddCartJewellery1.Click += new System.EventHandler(this.btn_AddCartJewellery1_Click);
            // 
            // lb_HargaNecklaceJewellery
            // 
            this.lb_HargaNecklaceJewellery.AutoSize = true;
            this.lb_HargaNecklaceJewellery.Location = new System.Drawing.Point(197, 305);
            this.lb_HargaNecklaceJewellery.Name = "lb_HargaNecklaceJewellery";
            this.lb_HargaNecklaceJewellery.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaNecklaceJewellery.TabIndex = 17;
            this.lb_HargaNecklaceJewellery.Text = "Rp. 650.000,-";
            // 
            // pBox_Jewelleries1
            // 
            this.pBox_Jewelleries1.Image = global::W9_Take_Home_New.Properties.Resources.Ring_Jewellery;
            this.pBox_Jewelleries1.Location = new System.Drawing.Point(12, 25);
            this.pBox_Jewelleries1.Name = "pBox_Jewelleries1";
            this.pBox_Jewelleries1.Size = new System.Drawing.Size(158, 246);
            this.pBox_Jewelleries1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Jewelleries1.TabIndex = 16;
            this.pBox_Jewelleries1.TabStop = false;
            // 
            // lb_HargaRingJewellery
            // 
            this.lb_HargaRingJewellery.AutoSize = true;
            this.lb_HargaRingJewellery.Location = new System.Drawing.Point(12, 305);
            this.lb_HargaRingJewellery.Name = "lb_HargaRingJewellery";
            this.lb_HargaRingJewellery.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaRingJewellery.TabIndex = 16;
            this.lb_HargaRingJewellery.Text = "Rp. 600.000,-";
            // 
            // pBox_Jewelleries3
            // 
            this.pBox_Jewelleries3.Image = global::W9_Take_Home_New.Properties.Resources.Bracelet_Jewellery;
            this.pBox_Jewelleries3.Location = new System.Drawing.Point(384, 25);
            this.pBox_Jewelleries3.Name = "pBox_Jewelleries3";
            this.pBox_Jewelleries3.Size = new System.Drawing.Size(158, 246);
            this.pBox_Jewelleries3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Jewelleries3.TabIndex = 15;
            this.pBox_Jewelleries3.TabStop = false;
            // 
            // lb_BraceletJewellery
            // 
            this.lb_BraceletJewellery.AutoSize = true;
            this.lb_BraceletJewellery.Location = new System.Drawing.Point(383, 280);
            this.lb_BraceletJewellery.Name = "lb_BraceletJewellery";
            this.lb_BraceletJewellery.Size = new System.Drawing.Size(136, 20);
            this.lb_BraceletJewellery.TabIndex = 15;
            this.lb_BraceletJewellery.Text = "Bracelet Jewellery";
            // 
            // pBox_Jewelleries2
            // 
            this.pBox_Jewelleries2.Image = global::W9_Take_Home_New.Properties.Resources.Necklace_Jewellery;
            this.pBox_Jewelleries2.Location = new System.Drawing.Point(198, 25);
            this.pBox_Jewelleries2.Name = "pBox_Jewelleries2";
            this.pBox_Jewelleries2.Size = new System.Drawing.Size(158, 246);
            this.pBox_Jewelleries2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Jewelleries2.TabIndex = 14;
            this.pBox_Jewelleries2.TabStop = false;
            // 
            // lb_NecklaceJewellery
            // 
            this.lb_NecklaceJewellery.AutoSize = true;
            this.lb_NecklaceJewellery.Location = new System.Drawing.Point(197, 280);
            this.lb_NecklaceJewellery.Name = "lb_NecklaceJewellery";
            this.lb_NecklaceJewellery.Size = new System.Drawing.Size(142, 20);
            this.lb_NecklaceJewellery.TabIndex = 14;
            this.lb_NecklaceJewellery.Text = "Necklace Jewellery";
            // 
            // lb_RingJewellery
            // 
            this.lb_RingJewellery.AutoSize = true;
            this.lb_RingJewellery.Location = new System.Drawing.Point(12, 280);
            this.lb_RingJewellery.Name = "lb_RingJewellery";
            this.lb_RingJewellery.Size = new System.Drawing.Size(110, 20);
            this.lb_RingJewellery.TabIndex = 13;
            this.lb_RingJewellery.Text = "Ring Jewellery";
            // 
            // pnl_Others
            // 
            this.pnl_Others.Controls.Add(this.tb_ItemPrice);
            this.pnl_Others.Controls.Add(this.label1);
            this.pnl_Others.Controls.Add(this.tb_ItemName);
            this.pnl_Others.Controls.Add(this.btn_Upload);
            this.pnl_Others.Controls.Add(this.btn_AddCartOthers);
            this.pnl_Others.Controls.Add(this.pBox_Others);
            this.pnl_Others.Controls.Add(this.lb_ItemName);
            this.pnl_Others.Controls.Add(this.lb_UploadImage);
            this.pnl_Others.Location = new System.Drawing.Point(0, 53);
            this.pnl_Others.Name = "pnl_Others";
            this.pnl_Others.Size = new System.Drawing.Size(557, 474);
            this.pnl_Others.TabIndex = 19;
            this.pnl_Others.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_Others_Paint);
            // 
            // tb_ItemPrice
            // 
            this.tb_ItemPrice.Location = new System.Drawing.Point(304, 200);
            this.tb_ItemPrice.Name = "tb_ItemPrice";
            this.tb_ItemPrice.Size = new System.Drawing.Size(134, 26);
            this.tb_ItemPrice.TabIndex = 19;
            this.tb_ItemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_ItemPrice_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(300, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 20);
            this.label1.TabIndex = 18;
            this.label1.Text = "Item Price:";
            // 
            // tb_ItemName
            // 
            this.tb_ItemName.Location = new System.Drawing.Point(304, 127);
            this.tb_ItemName.Name = "tb_ItemName";
            this.tb_ItemName.Size = new System.Drawing.Size(134, 26);
            this.tb_ItemName.TabIndex = 17;
            // 
            // btn_Upload
            // 
            this.btn_Upload.Location = new System.Drawing.Point(250, 46);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(155, 34);
            this.btn_Upload.TabIndex = 14;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.UseVisualStyleBackColor = true;
            this.btn_Upload.Click += new System.EventHandler(this.btn_Upload_Click);
            // 
            // btn_AddCartOthers
            // 
            this.btn_AddCartOthers.Location = new System.Drawing.Point(304, 287);
            this.btn_AddCartOthers.Name = "btn_AddCartOthers";
            this.btn_AddCartOthers.Size = new System.Drawing.Size(113, 38);
            this.btn_AddCartOthers.TabIndex = 13;
            this.btn_AddCartOthers.Text = "Add to Cart";
            this.btn_AddCartOthers.UseVisualStyleBackColor = true;
            this.btn_AddCartOthers.Click += new System.EventHandler(this.btn_AddCartOthers_Click);
            // 
            // pBox_Others
            // 
            this.pBox_Others.Location = new System.Drawing.Point(121, 101);
            this.pBox_Others.Name = "pBox_Others";
            this.pBox_Others.Size = new System.Drawing.Size(158, 246);
            this.pBox_Others.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_Others.TabIndex = 16;
            this.pBox_Others.TabStop = false;
            // 
            // lb_ItemName
            // 
            this.lb_ItemName.AutoSize = true;
            this.lb_ItemName.Location = new System.Drawing.Point(300, 104);
            this.lb_ItemName.Name = "lb_ItemName";
            this.lb_ItemName.Size = new System.Drawing.Size(91, 20);
            this.lb_ItemName.TabIndex = 16;
            this.lb_ItemName.Text = "Item Name:";
            // 
            // lb_UploadImage
            // 
            this.lb_UploadImage.AutoSize = true;
            this.lb_UploadImage.Location = new System.Drawing.Point(117, 53);
            this.lb_UploadImage.Name = "lb_UploadImage";
            this.lb_UploadImage.Size = new System.Drawing.Size(109, 20);
            this.lb_UploadImage.TabIndex = 13;
            this.lb_UploadImage.Text = "Upload Image";
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(573, 385);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(103, 38);
            this.btn_Delete.TabIndex = 20;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // Form_UNIQME
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 568);
            this.Controls.Add(this.pnl_Others);
            this.Controls.Add(this.pnl_Jewellery);
            this.Controls.Add(this.pnl_Shoes);
            this.Controls.Add(this.pnl_LongPants);
            this.Controls.Add(this.pnl_Pants);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.pnl_Shirt);
            this.Controls.Add(this.pnl_TShirt);
            this.Controls.Add(this.tb_Total);
            this.Controls.Add(this.tb_SubTotal);
            this.Controls.Add(this.lb_Total);
            this.Controls.Add(this.lb_SubTotal);
            this.Controls.Add(this.dgv_Produk);
            this.Controls.Add(this.menuStripUniqme);
            this.Name = "Form_UNIQME";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.Form_UNIQME_Load);
            this.pnl_TShirt.ResumeLayout(false);
            this.pnl_TShirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_TShirt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_TShirt3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_TShirt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Produk)).EndInit();
            this.menuStripUniqme.ResumeLayout(false);
            this.menuStripUniqme.PerformLayout();
            this.pnl_Shirt.ResumeLayout(false);
            this.pnl_Shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shirt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shirt3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shirt2)).EndInit();
            this.pnl_Pants.ResumeLayout(false);
            this.pnl_Pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Pants1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Pants3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Pants2)).EndInit();
            this.pnl_LongPants.ResumeLayout(false);
            this.pnl_LongPants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_LongPants1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_LongPants3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_LongPants2)).EndInit();
            this.pnl_Shoes.ResumeLayout(false);
            this.pnl_Shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shoe1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shoe3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Shoe2)).EndInit();
            this.pnl_Jewellery.ResumeLayout(false);
            this.pnl_Jewellery.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Jewelleries1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Jewelleries3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Jewelleries2)).EndInit();
            this.pnl_Others.ResumeLayout(false);
            this.pnl_Others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_Others)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_TShirt;
        private System.Windows.Forms.PictureBox pBox_TShirt1;
        private System.Windows.Forms.Button btn_AddCartTShirt3;
        private System.Windows.Forms.Button btn_AddCartTShirt2;
        private System.Windows.Forms.Button btn_AddCartTShirt1;
        private System.Windows.Forms.Label lb_HargaTShirtVNeck;
        private System.Windows.Forms.Label lb_HargaTShirtAIRism;
        private System.Windows.Forms.Label lb_HargaTShirtKerahBulat;
        private System.Windows.Forms.Label lb_TShirtVNeck;
        private System.Windows.Forms.Label lb_TShirtAIRism;
        private System.Windows.Forms.Label lb_TShirtKerahBulat;
        private System.Windows.Forms.PictureBox pBox_TShirt3;
        private System.Windows.Forms.PictureBox pBox_TShirt2;
        private System.Windows.Forms.TextBox tb_Total;
        private System.Windows.Forms.TextBox tb_SubTotal;
        private System.Windows.Forms.Label lb_Total;
        private System.Windows.Forms.Label lb_SubTotal;
        private System.Windows.Forms.DataGridView dgv_Produk;
        private System.Windows.Forms.MenuStrip menuStripUniqme;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.Panel pnl_Shirt;
        private System.Windows.Forms.PictureBox pBox_Shirt1;
        private System.Windows.Forms.Button btn_AddCartShirt3;
        private System.Windows.Forms.Button btn_AddCart2;
        private System.Windows.Forms.Button btn_AddCartShirt1;
        private System.Windows.Forms.Label lb_HargaCottonShirt;
        private System.Windows.Forms.Label lb_HargaClassicWhiteShirt;
        private System.Windows.Forms.Label lb_HargaShortSleeveShirt;
        private System.Windows.Forms.Label lb_CottonShirt;
        private System.Windows.Forms.Label lb_ClassicWhiteShirt;
        private System.Windows.Forms.Label lb_ShortSleeveShirt;
        private System.Windows.Forms.PictureBox pBox_Shirt3;
        private System.Windows.Forms.PictureBox pBox_Shirt2;
        private System.Windows.Forms.Panel pnl_Pants;
        private System.Windows.Forms.PictureBox pBox_Pants1;
        private System.Windows.Forms.Button btn_AddCartPants3;
        private System.Windows.Forms.Button btn_AddCartPants2;
        private System.Windows.Forms.Button btn_AddCartPants1;
        private System.Windows.Forms.Label lb_HargaWomenPants;
        private System.Windows.Forms.Label lb_HargaBlackAnklePants;
        private System.Windows.Forms.Label lb_HargaLightPants;
        private System.Windows.Forms.Label lb_WomenPants;
        private System.Windows.Forms.Label lb_BlackAnklePants;
        private System.Windows.Forms.Label lb_LightPants;
        private System.Windows.Forms.PictureBox pBox_Pants3;
        private System.Windows.Forms.PictureBox pBox_Pants2;
        private System.Windows.Forms.Panel pnl_LongPants;
        private System.Windows.Forms.PictureBox pBox_LongPants1;
        private System.Windows.Forms.Button btn_AddCartLongPants3;
        private System.Windows.Forms.Button btn_AddCartLongPants2;
        private System.Windows.Forms.Button btn_AddCartLongPants1;
        private System.Windows.Forms.Label lb_HargaCasualLongPants;
        private System.Windows.Forms.Label lb_HargaBlackLongPants;
        private System.Windows.Forms.Label lb_HargaCargoLongPants;
        private System.Windows.Forms.Label lb_CasualLongPants;
        private System.Windows.Forms.Label lb_BlackLongPants;
        private System.Windows.Forms.Label lb_CargoLongPants;
        private System.Windows.Forms.PictureBox pBox_LongPants3;
        private System.Windows.Forms.PictureBox pBox_LongPants2;
        private System.Windows.Forms.Panel pnl_Shoes;
        private System.Windows.Forms.PictureBox pBox_Shoe1;
        private System.Windows.Forms.Button btn_AddCartShoe3;
        private System.Windows.Forms.Button btn_AddCartShoe2;
        private System.Windows.Forms.Button btn_AddCartShoe1;
        private System.Windows.Forms.Label lb_HargaFlatShoes;
        private System.Windows.Forms.Label lb_HargaSneakersShoes;
        private System.Windows.Forms.Label lb_HargaRunningShoes;
        private System.Windows.Forms.Label lb_FlatShoes;
        private System.Windows.Forms.Label lb_SneakersShoes;
        private System.Windows.Forms.Label lb_RunningShoes;
        private System.Windows.Forms.PictureBox pBox_Shoe3;
        private System.Windows.Forms.PictureBox pBox_Shoe2;
        private System.Windows.Forms.Panel pnl_Jewellery;
        private System.Windows.Forms.Button btn_AddCartJewellery3;
        private System.Windows.Forms.Button btn_AddCartJewellery2;
        private System.Windows.Forms.Label lb_HargaBraceletJewellery;
        private System.Windows.Forms.Button btn_AddCartJewellery1;
        private System.Windows.Forms.Label lb_HargaNecklaceJewellery;
        private System.Windows.Forms.PictureBox pBox_Jewelleries1;
        private System.Windows.Forms.Label lb_HargaRingJewellery;
        private System.Windows.Forms.PictureBox pBox_Jewelleries3;
        private System.Windows.Forms.Label lb_BraceletJewellery;
        private System.Windows.Forms.PictureBox pBox_Jewelleries2;
        private System.Windows.Forms.Label lb_NecklaceJewellery;
        private System.Windows.Forms.Label lb_RingJewellery;
        private System.Windows.Forms.Panel pnl_Others;
        private System.Windows.Forms.Button btn_Upload;
        private System.Windows.Forms.Button btn_AddCartOthers;
        private System.Windows.Forms.PictureBox pBox_Others;
        private System.Windows.Forms.Label lb_ItemName;
        private System.Windows.Forms.Label lb_UploadImage;
        private System.Windows.Forms.TextBox tb_ItemPrice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_ItemName;
        private System.Windows.Forms.Button btn_Delete;
    }
}

